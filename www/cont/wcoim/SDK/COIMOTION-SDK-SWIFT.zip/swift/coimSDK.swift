//
//  coimSDK.swift
//  swiftCoimSDK
//
//  Created by Gocharm on 2014/7/9.
//  Copyright (c) 2014年 Gocharm. All rights reserved.
//

#if os(iOS)
    import UIKit
#else
    import Foundation
    import AppKit
#endif

class coimSDK
{
    private struct vars {
        static let version:String = "0.9.6.2"
        static let maxFileSize = 1000 * 1000
        static var plistPath:String = String()
        static var appKey:String = String()
        static var appCode:String = String()
        static var timeoutInterval:Int = 30
        static var responseCode:Int = 0
        static var responseMessage:String = String()
    }

    enum nType: Int {
        case NICON = 1, NFILE, NIMAGE, NAUDIO, NVIDEO
    }
    
    class func initSDK(callback: (String) -> Void) {
        println("SDK Version: \(vars.version)")
        dLog("Enabled")
        
        if vars.plistPath.isEmpty {
            vars.appKey = ((NSBundle.mainBundle().infoDictionary["coim_app_key"] == nil) ? "" : NSBundle.mainBundle().infoDictionary["coim_app_key"]) as String
            vars.appCode = ((NSBundle.mainBundle().infoDictionary["coim_app_code"] == nil) ? "" : NSBundle.mainBundle().infoDictionary["coim_app_code"]) as String
            if NSBundle.mainBundle().infoDictionary["coim_timeout"]? != nil {
                vars.timeoutInterval = (NSBundle.mainBundle().infoDictionary["coim_timeout"]! as Int)
                if vars.timeoutInterval <= 0 {
                    vars.timeoutInterval = 30
                }
            }
            else {
                println("coim_timeout's type must be Number (in plist), set to default (30s)")
            }
            dLog("timeout: \(vars.timeoutInterval)s")
            
            if vars.appKey == "" || vars.appCode == "" {
                callback("Please set coim_app_key and coim_app_code");
                return;
            }
            
            var paths = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.UserDomainMask, true)
            vars.plistPath = (paths[0] as String).stringByAppendingString("/coimotion.plist")
            if !NSFileManager().fileExistsAtPath(vars.plistPath) {
                if NSDictionary().writeToFile(vars.plistPath, atomically:true) {
                    println("plist created")
                }
            }
        }
        callback("SDK initialized");
    }
    
    class func sendTo(relativeURL: String, params: NSMutableDictionary = NSMutableDictionary(),aDelegate: coimDelegateProtocol) -> NSURLConnection {
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        for (key, value) in params {
            if value.isKindOfClass(NSArray) {
                var newValue = NSString(data:NSJSONSerialization.dataWithJSONObject(value, options: NSJSONWritingOptions.PrettyPrinted, error: nil), encoding:NSUTF8StringEncoding)
                params[key as String] = newValue
            }
            
        }
        params.setValue(vars.appKey, forKey: "_key")
        params.setValue(getProperty("token"), forKey: "token")
        let urlPath: String = "http://" + vars.appCode + ".coimapi.tw/" + relativeURL

        dLog("sendTo url: \(urlPath)")
        dLog("with Params: \(params)")
        
        var url: NSURL = NSURL(string: urlPath)
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted, error: nil)
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func loginTo(relativeURL: String, params: NSMutableDictionary,aDelegate: coimDelegateProtocol) -> NSURLConnection {
        var accName : AnyObject? = params["accName"]?
        var passwd : AnyObject? = params["passwd"]?
        
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if accName? == nil || passwd? == nil {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "Lack of accName or passwd", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        setProperty("accName", value:(accName as String))
        var salt = sha1((accName as String))
        var saltPass = sha1(salt+(passwd as String))
        params["passwd"] = saltPass
        params.setValue(vars.appKey, forKey: "_key")
        
        let urlPath: String = "https://" + vars.appCode + ".coimapi.tw/" + relativeURL
        
        dLog("loginTo url: \(urlPath)")
        dLog("with Params: \(params)")
        
        var url: NSURL = NSURL(string: urlPath)
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted, error: nil)
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func register(params: NSMutableDictionary,aDelegate: coimDelegateProtocol) -> NSURLConnection {
        var accName : AnyObject? = params["accName"]?
        var passwd : AnyObject? = params["passwd"]?
        var passwd2 : AnyObject? = params["passwd2"]?
        
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if accName? == nil || passwd? == nil || passwd2? == nil{
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "Lack of oldPasswd, passwd or new passwd", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if (passwd! as String).isEmpty || (passwd2! as String).isEmpty || (accName! as String).isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "accName/password cannot be empty", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        var salt = sha1(accName as String)
        var saltPass = sha1(salt+(passwd as String))
        params["passwd"] = saltPass
        saltPass = sha1(salt+(passwd2 as String))
        params["passwd2"] = saltPass
        
        setProperty("accName", value:(accName as String))
        params.setValue(vars.appKey, forKey: "_key")
        params.setValue(getLocale(), forKey:"_loc")
        
        let urlPath: String = "https://" + vars.appCode + ".coimapi.tw/core/user/register"
        dLog("register url: \(urlPath)")
        dLog("with Params: \(params)")
        
        var url: NSURL = NSURL(string: urlPath)
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted, error: nil)
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func updPasswd(params: NSMutableDictionary,aDelegate: coimDelegateProtocol) -> NSURLConnection {
        var oldPasswd : AnyObject? = params["oldPasswd"]?
        var passwd : AnyObject? = params["passwd"]?
        var passwd2 : AnyObject? = params["passwd2"]?
        var accName = getProperty("accName")
        
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if oldPasswd? == nil || passwd? == nil || passwd2? == nil{
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "Lack of oldPasswd, passwd or new passwd", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if (passwd! as String).isEmpty || (passwd2! as String).isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "password cannot be empty", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        var salt = sha1((accName as String))
        var saltPass = sha1(salt+(passwd as String))
        params["passwd"] = saltPass
        saltPass = sha1(salt+(passwd2 as String))
        params["passwd2"] = saltPass
        saltPass = sha1(salt+(oldPasswd as String))
        params["oldPasswd"] = saltPass
        
        params.setValue(vars.appKey, forKey: "_key")
        params.setValue(getProperty("token"), forKey: "token")
        
        let urlPath: String = "https://" + vars.appCode + ".coimapi.tw/core/user/updPasswd"
        
        dLog("upate passwd url: \(urlPath)")
        dLog("with Params: \(params)")
        var url: NSURL = NSURL(string: urlPath)
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted, error: nil)
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func logout(aDelegate: coimDelegateProtocol) -> NSURLConnection {
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        var params = NSMutableDictionary()
        params.setValue(vars.appKey, forKey: "_key")
        params.setValue(getProperty("token"), forKey: "token")
        setProperty("token", value: "")
        setProperty("accName", value: "")
        let urlPath: String = "http://" + vars.appCode + ".coimapi.tw/core/user/logout"
        dLog("logout url: \(urlPath)")
        dLog("with Params: \(params)")
        
        var url: NSURL = NSURL(string: urlPath)
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.HTTPBody = NSJSONSerialization.dataWithJSONObject(params, options: NSJSONWritingOptions.PrettyPrinted, error: nil)
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func attach(files: NSArray, toURL: String, params:NSMutableDictionary, aDelegate:coimDelegateProtocol) -> NSURLConnection {
        if vars.plistPath.isEmpty {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "not initialized", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if params["nType"]? == nil {
            var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "lack of parameters", NSLocalizedDescriptionKey)
            var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
            aDelegate.coimConnection(NSURLConnection(), error: error)
            return NSURLConnection()
        }
        
        if files.count == 0 {
            if params["dataURI"]? != nil {
                return sendTo(toURL, params:params, aDelegate:aDelegate);
            }
            else {
                var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "lack of files or dataURI", NSLocalizedDescriptionKey)
                var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
                aDelegate.coimConnection(NSURLConnection(), error: error)
                return NSURLConnection()
            }
        }
        
        var totalSize:Int = 0
        for var i=0; i < files.count; i++ {
            var fileManager = NSFileManager.defaultManager()
            var filePath = files.objectAtIndex(i) as String
            if filePath.hasPrefix("file://") {
                filePath = filePath.stringByReplacingOccurrencesOfString("file://", withString: "")
            }
            
            if !fileManager.fileExistsAtPath(filePath) {
                var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "file(s) is not existed", NSLocalizedDescriptionKey)
                var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
                aDelegate.coimConnection(NSURLConnection(), error: error)
                return NSURLConnection()
            }
            else {
                var error: NSError?
                var fileInfo = fileManager.attributesOfItemAtPath(filePath, error: &error)
                
                if error? != nil {
                    aDelegate.coimConnection(NSURLConnection(), error: error!)
                    return NSURLConnection()
                }
                dLog("size: \(fileInfo[NSFileSize])")
                totalSize += (fileInfo[NSFileSize]!) as Int
                
                if totalSize > vars.maxFileSize {
                    var userInfo:NSDictionary = NSDictionary(objectsAndKeys: "size of all files is over 1 M", NSLocalizedDescriptionKey)
                    var error = NSError(domain: "com.coimotion.csdk", code: -101, userInfo: userInfo)
                    aDelegate.coimConnection(NSURLConnection(), error: error)
                    return NSURLConnection()
                }
            }
        }
        
        var urlPath = "http://\(vars.appCode).coimapi.tw/\(toURL)"
        
        dLog("attach url: \(urlPath)")
        dLog("with Params: \(params)")
        dLog("files: \(files)")
        
        var boundary = "------\((Int(NSDate().timeIntervalSince1970)))\(Int(arc4random()%1000))"
        var url: NSURL = NSURL(string: urlPath)
        var body = NSMutableData.data()
        var req: NSMutableURLRequest = NSMutableURLRequest(URL: url, cachePolicy: NSURLRequestCachePolicy.ReloadIgnoringLocalCacheData, timeoutInterval: Double(vars.timeoutInterval))
        req.addValue(getUUID(), forHTTPHeaderField: "X-COIM-ClientKey")
        req.HTTPMethod = "post"
        req.addValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        var token = getProperty("token")
        if !token.isEmpty {
            dLog("token: \(token)")
            body.appendData(("--\(boundary)\r\nContent-Disposition: form-data; name=\"token\"\r\n\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
            body.appendData(("\(token)\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
        }
        var nType: AnyObject = params["nType"]
        body.appendData(("--\(boundary)\r\nContent-Disposition: form-data; name=\"nType\"\r\n\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
        body.appendData(("\(nType)\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
        
        var title: AnyObject? = params["title"]?
        if title? != nil {
            body.appendData(("--\(boundary)\r\nContent-Disposition: form-data; name=\"title\"\r\n\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
            body.appendData(("\(title!)\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
        }
        
        for var i=0; i < files.count; i++ {
            var filePath = files.objectAtIndex(i) as String
            var fileName:String = String()
            if filePath.hasPrefix("file://") {
                filePath = filePath.stringByReplacingOccurrencesOfString("file://", withString: "")
            }
            var fileURL = NSURL.fileURLWithPath(filePath)
            var fileReq = NSURLRequest(URL: fileURL)
            
            var error: NSError?
            var response: NSURLResponse?
            var fileData = NSURLConnection.sendSynchronousRequest(fileReq, returningResponse: &response, error: &error)
            if error? != nil {
                dLog("error: \(error!.localizedDescription)")
                aDelegate.coimConnection(NSURLConnection(), error: error!)
                return NSURLConnection()
            }
            
            if response? != nil {
                var mimeType = response!.MIMEType
                var parts = fileURL.pathComponents
                fileName = parts[parts.count-1] as String
                if fileData != nil {
                    body.appendData(("--\(boundary)\r\nContent-Disposition: form-data; name=\"att\(i)\"; filename=\"\(fileName)\"\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
                    body.appendData(("Content-Type: \(mimeType)\r\n\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
                    body.appendData(fileData)
                    body.appendData(("\r\n").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
                }
            }
        }
        body.appendData(("--\(boundary)--").dataUsingEncoding(NSUTF8StringEncoding, allowLossyConversion: true))
        req.HTTPBody = body!
        var myDelegate = coimConnectionDelegate(aDelegate: aDelegate)
        return NSURLConnection.connectionWithRequest(req, delegate: myDelegate)
    }
    
    class func checkNetwork() -> Bool {
        var reachability = Reachability.reachabilityForInternetConnection()
        var networkStatus = reachability.currentReachabilityStatus()
        return (networkStatus.value != NotReachable.value)
    }
    
    class func getErrCodeFrom(data: NSDictionary) -> Int {
        var errCode:AnyObject? = data["errCode"]?
        if errCode? != nil {
            return errCode! as Int
        }
        else {
            return -5000
        }
    }
    
    class func getValueFrom(data: NSDictionary) -> NSDictionary {
        var value:AnyObject? = data["value"]?
        if value? != nil {
            return value! as NSDictionary
        }
        else {
            return NSDictionary()
        }
    }
    
    class func getListFrom(data: NSDictionary) -> NSArray {
        var value = getValueFrom(data)
        if value != nil {
            var list:AnyObject? = value["list"]?
            if list? != nil {
                return list! as NSArray
            }
            else {
                NSArray()
            }
        }
        return NSArray()
    }
    
    class func getMessageFrom(data: NSDictionary) -> String {
        var message:AnyObject? = data["message"]?
        if message? != nil {
            return message! as String
        }
        else {
            return String()
        }
    }
    
    #if	os(iOS)
        class func showAlert(msg: String, alertDelegate:UIViewController) {
            var alert = UIAlertController(title: "相關訊息", message: msg, preferredStyle: UIAlertControllerStyle.Alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.Default, handler: nil))
            alertDelegate.presentViewController(alert, animated: true, completion: nil)
        }
    #else
        class func showAlert(msg: String) {
            let myPopup:NSAlert = NSAlert()
            myPopup.informativeText = msg
            myPopup.messageText = "相關訊息"
            myPopup.runModal()
        }
    #endif
    
    private class func getUUID()->String
    {
        #if	os(iOS)
            return UIDevice.currentDevice().identifierForVendor.UUIDString
            #else
            var args:NSArray = ["-rd1", "-c", "IOPlatformExpertDevice", "|", "grep", "model"]
            var task = NSTask()
            task.launchPath = "/usr/sbin/ioreg"
            task.arguments = args
            var pipe = NSPipe()
            task.standardOutput = pipe
            task.launch()
            
            var arg2 = ["/IOPlatformUUID/ { split($0, line, \"\\\"\"); printf(\"%s\\n\", line[4]); }"]
            var task2 = NSTask()
            task2.launchPath = "/usr/bin/awk"
            task2.arguments = arg2
            var pipe2 = NSPipe()
            task2.standardInput = pipe
            task2.standardOutput = pipe2
            var fileHandle2 = pipe2.fileHandleForReading
            task2.launch()
            var data = fileHandle2.readDataToEndOfFile()
            var uuid = NSString(data: data, encoding :NSUTF8StringEncoding)
            return uuid.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        #endif
    }
    
    private class func getLocale() -> String
    {
        return NSLocale.preferredLanguages()[0].rangeOfString("zh").location == NSNotFound ? "1" : "2"
    }
    
    private class func setProperty(key: String,value:String)
    {
        var dic:NSMutableDictionary  = NSMutableDictionary(contentsOfFile: vars.plistPath)
        
        if value.isEmpty {
            dLog("\(key) removed")
            dic.removeObjectForKey(key)
        }
        else {
            dic.setValue(value, forKey: key);
        }
        dic.writeToFile(vars.plistPath, atomically: true)
        dLog("\(key) updated")
    }
    
    class func getProperty(key:String) -> String
    {
        if vars.plistPath.isEmpty {
            return String();
        }
        var dic:NSDictionary  = NSDictionary(contentsOfFile: vars.plistPath)
        if dic[key] == nil {
            return String();
        }
        else {
            return dic[key] as String
        }
    }
    
    private class func sha1(input:String) -> String
    {
        let data = input.dataUsingEncoding(NSUTF8StringEncoding)!
        var dataLen:CC_LONG = CC_LONG(data.length)
        let result = UnsafeMutablePointer<CUnsignedChar>.alloc(Int(CC_SHA1_DIGEST_LENGTH))
        CC_SHA1(data.bytes ,dataLen, result)
        
        var hash = NSMutableString()
        for i in 0...(Int(CC_SHA1_DIGEST_LENGTH)-1) {
            hash.appendFormat("%02x", result[i])
        }
        
        result.destroy()
        return String(format: hash)
    }
    
    private class func dLog(message:String) {
        var debug:Bool = false
        if NSBundle.mainBundle().objectForInfoDictionaryKey("coim_debug") is Bool {
            debug = NSBundle.mainBundle().objectForInfoDictionaryKey("coim_debug") as Bool
        }
        
        if debug {
            println("[DEBUG] - \(message)")
        }
    }
    
    class coimConnectionDelegate: NSObject, NSURLConnectionDelegate{
        var mData = NSMutableData()
        var mDelegate: coimDelegateProtocol
        
        init(aDelegate: coimDelegateProtocol)
        {
            mDelegate = aDelegate
        }
        
        func connection(connection: NSURLConnection!, didReceiveData data: NSData!)
        {
            mData.appendData(data)
        }
        
        func connection(connection: NSURLConnection!, didSendBodyData bytesWritten: Int, totalBytesWritten: Int, totalBytesExpectedToWrite: Int)
        {
            var prog = (Float(totalBytesWritten * 100)/Float(totalBytesExpectedToWrite))
            mDelegate.coimConnection?(connection, percentage:prog)
        }
        
        /*- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
        {
        totalDataSize = [response expectedContentLength];
        responseCode = (int)((NSHTTPURLResponse *)response).statusCode;
        responseMessage = [NSHTTPURLResponse localizedStringForStatusCode:((NSHTTPURLResponse *)response).statusCode]; //[((NSHTTPURLResponse *) response).statusCode]
        }*/
        
        func connection(connection: NSURLConnection!, didReceiveResponse: NSURLResponse) {
            vars.responseCode = (didReceiveResponse as NSHTTPURLResponse).statusCode;
            vars.responseMessage = NSHTTPURLResponse.localizedStringForStatusCode(vars.responseCode)
        }
        
        func connectionDidFinishLoading(connection: NSURLConnection!)
        {
            if vars.responseCode != 200 {
                var userInfo:NSDictionary = NSDictionary(objectsAndKeys: vars.responseMessage, NSLocalizedDescriptionKey)
                var error = NSError(domain: "com.coimotion.csdk", code: vars.responseCode, userInfo: userInfo)
                mDelegate.coimConnection(connection, error: error)
                return;
            }
            
            var error: NSError?
            var jsonResult = NSJSONSerialization.JSONObjectWithData(mData, options: NSJSONReadingOptions.MutableContainers, error: &error) as NSDictionary
            
            if connection.currentRequest.URL.path! == "/core/user/register" {
                var actID : AnyObject?
                if jsonResult["value"]? != nil {
                    actID = (jsonResult["value"]!)["actID"]?
                }
                if actID? == nil {
                    mDelegate.coimConnectionDidFinishLoading(connection, responseData: jsonResult)
                }
                else {
                    var path:String = "core/user/activate/\(actID!)";
                    var conn:NSURLConnection = coimSDK.sendTo(path, aDelegate:mDelegate)
                }
            }
            else {
                var token : AnyObject? = jsonResult["token"]?
                if token? != nil {
                    
                    coimSDK.setProperty("token", value: (token! as String))
                    if (token! as String).isEmpty {
                        mDelegate.coimConnectionInvalidToken?(connection)
                    }
                }

                mDelegate.coimConnectionDidFinishLoading(connection, responseData: jsonResult)
            }
        }
        
        func connection(connection: NSURLConnection!, didFailWithError error: NSError!)
        {
            mDelegate.coimConnection(connection, error: error)
        }
        
        /*
            these two is used for invalid SSL certification
        */
        func connection(connection: NSURLConnection!, canAuthenticateAgainstProtectionSpace protectionSpace: NSURLProtectionSpace!) -> Bool
        {
            return protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust
        }
        
        func connection(connection: NSURLConnection!, didReceiveAuthenticationChallenge challenge: NSURLAuthenticationChallenge!)
        {
            challenge.sender.useCredential(NSURLCredential(forTrust: challenge.protectionSpace.serverTrust), forAuthenticationChallenge: challenge)
            challenge.sender.continueWithoutCredentialForAuthenticationChallenge(challenge)
        }
    }
}

@objc protocol coimDelegateProtocol {
    func coimConnectionDidFinishLoading(connection: NSURLConnection, responseData: NSDictionary)
    func coimConnection(connection: NSURLConnection, error: NSError)
    optional func coimConnectionInvalidToken(connection:NSURLConnection)
    optional func coimConnection(conn: NSURLConnection, percentage:Float)
}